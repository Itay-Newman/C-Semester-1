void main()
{
	int a;
	printf(%d,a)
}