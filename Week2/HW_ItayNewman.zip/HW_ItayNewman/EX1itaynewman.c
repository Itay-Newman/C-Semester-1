#include <stdio.h>
int main()
{
	printf("This is not my first message\n");
	printf("I already printed Hello World\n");
	printf("Now everything is clear\n");
	printf("YUPY!!\n");
	getchar();
	
}
