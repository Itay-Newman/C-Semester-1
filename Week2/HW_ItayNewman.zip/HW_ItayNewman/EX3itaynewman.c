#include <stdio.h>
int main()
{
	printf("This is not my first message\nI already printed Hello World\nNow everything is clear\nYUPY!!\n");
	getchar();
	
}
