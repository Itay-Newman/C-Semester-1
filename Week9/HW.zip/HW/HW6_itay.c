int player1Turn();
int player2Turn();
int currentPosition();
int diceRoll();
int	checkIfPlayerGotTo100();
int ifPlayerGoOver100GoBack();
int stepOnLadder();
int stepOnSnake();
int gameOver();

int main()
{
	
}
int player1Turn()
{
	
}
int player2Turn()
{
	
}
int currentPosition()
{
	
}
int diceRoll()
{
	
}
int	checkIfPlayerGotTo100()
{
	
}
int ifPlayerGoOver100GoBack()
{
	
}
int stepOnLadder()
{
	
}
int stepOnSnake()
{
	
}
int gameOver()
{
	
}