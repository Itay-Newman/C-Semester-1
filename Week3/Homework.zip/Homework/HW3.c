#include <stdio.h>

int main(void) 
{
    unsigned int x = 0;
    
    x = x - 1;
    
    printf("%u", x);
    
    return 0;
}
