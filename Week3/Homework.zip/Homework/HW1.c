#include <stdio.h>

int main() {
    int a = 5;
    float b = 2.5;

    printf("a is: %d\n", a);
    printf("b is: %.2f\n", b);
	printf("a * b is: %.2f", (float)a * b);

    return 0;
}
