#include <stdio.h>

int main()
{
	int day = 12;
	int month = 11;
	int year = 2008;
	
	printf("%d/%d/%d\n", day, month, year);
	
	char day2 = '1';
	char day3 = '2';
	char month2 = '1';
	char month3 = '1';
	char year2 = '2';
	char year3 = '0';
	char year4 = '0';
	char year5 = '8';


	printf("%c%c/%c%c/%c%c%c%c", day2, day3, month2, month3, year2, year3, year4, year5);
	
	return 0;
}
