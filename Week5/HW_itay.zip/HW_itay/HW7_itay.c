//when the if's are inside eachother like this:
//if(xyz = true)
//{
//	if(abc = true)
	// printf("def")
//}
//then both have to be correct for the code but in the code you wrote:
//if(age >= 12)
//{
	//printf("you can have a smartphone")
//}
//if(age <= 18)
//{
	//printf("you can have a smartphone")
//}
//only one has to be true for the code to print and if both are correct it prints twice
